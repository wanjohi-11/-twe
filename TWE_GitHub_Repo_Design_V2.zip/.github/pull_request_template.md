## What changed?

## Why?

## Validation
- [ ] PHP syntax checks pass
- [ ] Affected routes tested
- [ ] Mobile UI checked where relevant
- [ ] Authorization checked where relevant
- [ ] No production secrets included

## Deployment impact
- [ ] No database change
- [ ] Migration included
- [ ] No environment change
- [ ] `.env.example` updated
