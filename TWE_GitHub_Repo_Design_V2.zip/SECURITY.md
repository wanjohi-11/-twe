# Security Policy

Do not report credential, authentication, authorization, payment or private-data vulnerabilities in a public issue.

Report security concerns privately to **hello@twe.co.ke**.

Production secrets must be loaded from `.env` and must never be committed. If a secret is committed, rotate it immediately.
