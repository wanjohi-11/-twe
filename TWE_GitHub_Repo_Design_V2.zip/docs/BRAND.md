# TWE Brand

**TWE — Technology. Work. Enterprise.**

**Technology that works.**

Core palette:
- Black `#080808`
- White `#FFFFFF`
- Gold `#C9A227`
- Carbon `#1C1C1C`
- Graphite `#505050`
- Warm canvas `#F7F6F2`
- Border grey `#E7E5E0`

Typography: Montserrat for interface/editorial; JetBrains Mono for technical surfaces.

Gold should be scarce. Prefer real product interfaces, architecture diagrams, code/terminal screenshots and useful photography. Avoid generic AI imagery and decorative noise.
