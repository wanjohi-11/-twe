# Contributing to TWE

Use short-lived `feature/`, `fix/`, `content/` and `chore/` branches.

Before merge:
- no production secrets
- no `.env`
- no customer database dumps
- PHP syntax checks pass
- affected routes tested
- mobile UI checked where relevant
- Control Centre authorization verified
- migrations/environment changes documented
