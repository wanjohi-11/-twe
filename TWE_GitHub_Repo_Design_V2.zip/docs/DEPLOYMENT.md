# TWE Deployment

Target: cPanel/shared hosting.

1. Validate the intended `main` commit.
2. Confirm `.env` is excluded.
3. Run PHP syntax checks.
4. Review migrations and `.env.example`.
5. Package without `.git`, logs, caches, credentials or production SQL dumps.
6. Back up production.
7. Deploy files.
8. Preserve/recreate server-side `.env`.
9. Apply migrations.
10. Run route, auth, email, tool, Control Centre and mobile health checks.
