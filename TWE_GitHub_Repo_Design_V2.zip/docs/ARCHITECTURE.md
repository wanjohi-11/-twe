# TWE Architecture

TWE owns public discovery, SEO content, articles, resources, anonymous tools and conversion context.

Imara Flow should own persistent business records: customers, products, invoices, sales, inventory, money records and workspaces.

Valron handles qualified implementation, integration, infrastructure and custom-software work.

Production must remain deployable to ordinary cPanel/shared hosting without requiring Composer or npm on the server.
