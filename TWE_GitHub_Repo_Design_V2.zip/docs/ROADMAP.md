# TWE Roadmap

## Foundation
- [ ] Import current production application source
- [ ] Complete Control Centre permissions
- [ ] Stable deployment/migration conventions
- [ ] Baseline analytics/error monitoring

## Knowledge
- [ ] Search-intent articles
- [ ] Technology / Work / Enterprise taxonomy
- [ ] Strong internal search
- [ ] Resource library

## Deep tools
- [ ] JSON/payload utilities
- [ ] HTTP/API diagnostics
- [ ] DNS/SEO checks
- [ ] Debugging helpers
- [ ] Invoice/quotation/receipt generators
- [ ] Margin and stock calculators

## Ecosystem
- [ ] Anonymous TWE result
- [ ] Signed save-to-Imara handoff
- [ ] Cross-domain attribution
- [ ] Contextual Valron implementation request
